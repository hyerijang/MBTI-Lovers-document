package kr.hogink.mbti.MBTILovers.web.friend;

import java.io.Serializable;


public class FriendDTO {

    private String fid;

    public String getFid() {
        return fid;
    }

    public void setFid(String fid) {
        this.fid = fid;
    }

}
