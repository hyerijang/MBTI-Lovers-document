package kr.hogink.mbti.MBTILovers.web.login;

public class LoginType {
    public static final String USER_MEMBER_SESSION = "currentUser";
    public static final String USER_UID_COOKIE = "currentUserUid";
    public static final String NEW_USER_UID_SESSION = "newUser";
}
