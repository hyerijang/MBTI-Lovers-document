package kr.hogink.mbti.MBTILovers.web.login;

//login을 위해 value를 전달합니다.
public class LoginVO {

    private String uid; // 아이디

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

}
