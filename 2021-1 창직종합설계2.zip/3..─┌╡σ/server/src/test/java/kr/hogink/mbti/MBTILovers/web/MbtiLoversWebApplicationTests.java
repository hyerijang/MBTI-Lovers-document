package kr.hogink.mbti.MBTILovers.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MbtiLoversWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
