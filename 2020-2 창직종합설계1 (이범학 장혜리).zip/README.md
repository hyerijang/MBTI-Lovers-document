# 2020-2 창직종합설계프로젝트1

## 과제명

안드로이드를 이용한 MBTI 소개팅 어플

## 팀명

MBTI 연애해

## 팀 구성

B511135 이범학 B711166 장혜리

## Github

https://github.com/hyerijang/MBTI
